CREATE DATABASE `universitymanagmentsystem` ;
USE `universitymanagmentsystem`;

CREATE TABLE `course` (
  `course_code` varchar(30) DEFAULT NULL,
  `course_name` varchar(30) DEFAULT NULL,
  `course_credit` int(11) DEFAULT NULL,
  `Dept_Name` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `studentcourseregistration` (
  `S_ID` varchar(30) DEFAULT NULL,
  `Dept_Name` varchar(50) DEFAULT NULL,
  `Semester` varchar(20) DEFAULT NULL,
  `S_Name` varchar(50) DEFAULT NULL,
  `Course_Code` varchar(30) DEFAULT NULL,
  `Course_Name` varchar(50) DEFAULT NULL,
  `Course_Credit` int(11) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `studentdetails` (
  `S_NAME` varchar(40) DEFAULT NULL,
  `S_ID` varchar(30) DEFAULT NULL,
  `EMAIL` varchar(100) DEFAULT NULL,
  `Phone_Number` int(15) DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Blood_Group` varchar(10) DEFAULT NULL,
  `Nationality` varchar(30) DEFAULT NULL,
  `Address` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `studentregistration` (
  `S_Name` varchar(50) DEFAULT NULL,
  `S_ID` varchar(20) DEFAULT NULL,
  `Dept_Name` varchar(50) DEFAULT NULL,
  `Semester` varchar(20) DEFAULT NULL,
  `Gender` varchar(20) DEFAULT NULL,
  `Blood_Group` varchar(20) DEFAULT NULL,
  `Nationality` varchar(30) DEFAULT NULL,
  `Mobile` int(15) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Address` varchar(1000) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Father_Name` varchar(50) DEFAULT NULL,
  `F_Ocupation` varchar(50) DEFAULT NULL,
  `F_Mobile` int(11) DEFAULT NULL,
  `Mother_Name` varchar(50) DEFAULT NULL,
  `M_Ocupation` varchar(50) DEFAULT NULL,
  `M_Mobile` int(11) DEFAULT NULL,
  `P_Address` varchar(500) DEFAULT NULL,
  `S_Pic` longblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE  `studentresultinsertion` (
  `S_ID` varchar(20) DEFAULT NULL,
  `S_Name` varchar(40) DEFAULT NULL,
  `Dept_Name` varchar(50) DEFAULT NULL,
  `Semester` varchar(20) DEFAULT NULL,
  `Course_code` varchar(30) DEFAULT NULL,
  `Course_Name` varchar(50) DEFAULT NULL,
  `course_credit` int(11) DEFAULT NULL,
  `Course_CGPA` decimal(7,2) DEFAULT NULL,
  `year` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `teachercourseregistration` (
  `T_ID` varchar(25) DEFAULT NULL,
  `COURSE_ID` varchar(6) DEFAULT NULL,
  `DEPT_NAME` varchar(40) DEFAULT NULL,
  `SEMESTER` varchar(20) DEFAULT NULL,
  `YEAR` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `teacherdetails` (
  `T_Name` varchar(50) DEFAULT NULL,
  `T_ID` varchar(30) DEFAULT NULL,
  `Dept` varchar(50) DEFAULT NULL,
  `Desig` varchar(50) DEFAULT NULL,
  `DateBirth` varchar(30) DEFAULT NULL,
  `Gender` varchar(30) DEFAULT NULL,
  `BloodGroup` varchar(30) DEFAULT NULL,
  `Nationality` varchar(30) DEFAULT NULL,
  `MaritialStatus` varchar(30) DEFAULT NULL,
  `Mobile` int(15) DEFAULT NULL,
  `Address` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `teacherregistration` (
  `T_Name` varchar(50) DEFAULT NULL,
  `T_ID` varchar(30) DEFAULT NULL,
  `Dept` varchar(50) DEFAULT NULL,
  `Desig` varchar(50) DEFAULT NULL,
  `DateBirth` varchar(30) DEFAULT NULL,
  `Gender` varchar(30) DEFAULT NULL,
  `BloodGroup` varchar(30) DEFAULT NULL,
  `Nationality` varchar(30) DEFAULT NULL,
  `MaritialStatus` varchar(30) DEFAULT NULL,
  `Mobile` int(15) DEFAULT NULL,
  `Address` varchar(1000) DEFAULT NULL,
  `U_Name` varchar(50) DEFAULT NULL,
  `undergradute` varchar(30) DEFAULT NULL,
  `CGPA` decimal(7,2) DEFAULT NULL,
  `UN_Name` varchar(50) DEFAULT NULL,
  `Graduate` varchar(50) DEFAULT NULL,
  `C_GPA` decimal(7,2) DEFAULT NULL,
  `Dept_Name` varchar(50) DEFAULT NULL,
  `T_Pic` longblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `teachersalary` (
  `TEA_ID` varchar(25) DEFAULT NULL,
  `DEPT_NAME` varchar(40) DEFAULT NULL,
  `DESIGNATION` varchar(20) DEFAULT NULL,
  `MONTH` varchar(15) DEFAULT NULL,
  `YEAR` int(11) DEFAULT NULL,
  `SALARY` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `userinfo` (
  `name` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `sec_q` varchar(50) DEFAULT NULL,
  `answer` varchar(100) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `userinfo` (`name`, `username`, `sec_q`, `answer`, `password`) VALUES
	('Shamiul', 'sam', 'what is your child friend name?', 'sssia', 't-virus');
	

